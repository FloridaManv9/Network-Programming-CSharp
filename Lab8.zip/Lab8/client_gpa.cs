using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net.Sockets;

namespace ClientSocket
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpClient client = new TcpClient("127.0.0.1", 2057);
            try
            {
			
                Stream s = client.GetStream();
                StreamReader sr = new StreamReader(s);
                StreamWriter sw = new StreamWriter(s);
                sw.AutoFlush = true;
                Console.WriteLine(sr.ReadLine());
				
                while (true)
                {
					string major = null;
					string nul = "Sorry, no such student!";
                    Console.WriteLine("Enter a student ID: ");
                    string title = Console.ReadLine();
                    sw.WriteLine(title);
                    if (title == "") 
						break;
                    major = sr.ReadLine();
					Console.Write(major + "\n");
					if (String.Equals(major, nul)){
						
					}
					else{
					sw.WriteLine(major);
					Console.WriteLine("\n" + sr.ReadLine() + " is the average GPA for the " + major + " major.");
					}
                }
                s.Close();
            }
            finally
            {
                client.Close();
            } 
 
        }
    }
}